 // alert('hello');
 const db_work = require('./db_work');

 const nodemailer = require('nodemailer');
 const xoauth2 = require('xoauth2');
 const gen_otp = require('./verify.js');

 function otp_generate(Email) {


     //alert('hello1');


     var email = document.getElementById('Email').value;
     alert(email);


     //  console.log(email)
     //-----------------------

     var otp = gen_otp.generate_otp(4);

     //-----------------------
     exports.sendEmail = function() {
         return (email);
     }
     exports.sendOtp = function() {
         return (otp);
     }


     let transporter = nodemailer.createTransport({
         host: 'smtp.gmail.com',
         port: 465,
         secure: true,
         auth: {
             type: 'OAuth2',
             user: 'saad.ahmed@onval.co',
             clientId: '366209567621-l6ifn5hp7alh3fn2iuc6tmuss3bug5i4.apps.googleusercontent.com',
             clientSecret: 'bq6WlQ8bS0LGi-4aQLVKSmoC',
             refreshToken: '1/ufShwABzttbcuYzxzBzBjFwP0_WiTPEPffB004EgYX6YyFtzssr2IA-cJ71sXvTy',
             accessToken: 'ya29.GltdB6ZzpsbMXIdLOsYYicsk0OX-g7bsa8_njg81FP2DhFq5dSERwnKmVMBzgMBZmqCyHQz8xQ6NaQNWKZAPcylmdtw0mYCL6vzvxg3_w0vA3rVt5BGNY4LENe5m'
         }
     });


     var mailOption = {
         from: 'Saad Ahmed <saad.ahmed@onval.co>',
         to: email,
         bcc: 'ahm33.saad@gmail.com',
         subject: 'Email Verification',
         text: 'Your 10th One Time Password for E-mail verification is' + otp
     }


     transporter.sendMail(mailOption, function(err, res) {
         if (err) {
             alert('Error: ' + err);
             //console.log("Error Occurred: " + err);
         } else {
             console.log('Mail sent Successfully!' + otp + " -- " + email);
             alert('mail sent!');
             alert('Mail sent Successfully!' + otp);
         }
     })

     db_work.db_log();


 }
 //  otp_generate();